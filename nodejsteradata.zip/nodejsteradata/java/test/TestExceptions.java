
public class TestExceptions {
  public TestExceptions(Exception ex) throws Exception { throw ex; }
}
